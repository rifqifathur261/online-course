module.exports = {
  publicPath: "./",
  transpileDependencies: ["vuetify"],
};
