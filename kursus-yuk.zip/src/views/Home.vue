<template>
  <list-course />
</template>

<script>
import ListCourse from "../components/ListCourse.vue";

export default {
  name: "Home",

  components: {
    ListCourse,
  },
};
</script>
