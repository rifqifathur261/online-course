<template>
  <div>
    Modul
  </div>
</template>

<script>
export default {
  props: ["modul"],
};
</script>

<style></style>
